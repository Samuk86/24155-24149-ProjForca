﻿//Rafael Ferreira Rigo - 24149
//Samuel Rosa Parra - 24155

public interface IRegistro
{
  string FormatoDeArquivo();
}

